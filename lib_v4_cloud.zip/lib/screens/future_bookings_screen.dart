import 'package:flutter/material.dart';

import '../services/booking_service.dart';
import 'booking_details_screen.dart';

class FutureBookingsScreen extends StatefulWidget {
  const FutureBookingsScreen({super.key});

  @override
  State<FutureBookingsScreen> createState() =>
      _FutureBookingsScreenState();
}

class _FutureBookingsScreenState
    extends State<FutureBookingsScreen> {
  final TextEditingController _searchController =
      TextEditingController();

  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day-$month-${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: BookingService.changeNotifier,
      builder: (context, _, __) {
        final futureBookings =
            BookingService.getFutureBookings();
        final bookings = BookingService.searchBookings(
          futureBookings,
          _searchQuery,
        );

        return Scaffold(
          appBar: AppBar(
            title: const Text('Future Bookings'),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText:
                        'Search by name, phone, or booking ID',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchQuery.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear search',
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              setState(() {
                                _searchQuery = '';
                              });
                            },
                          ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: bookings.isEmpty
                    ? Center(
                        child: Text(
                          _searchQuery.isEmpty
                              ? 'No Future Bookings'
                              : 'No matching bookings found',
                          style: const TextStyle(fontSize: 18),
                        ),
                      )
                    : ListView.builder(
                        padding:
                            const EdgeInsets.only(bottom: 12),
                        itemCount: bookings.length,
                        itemBuilder: (context, index) {
                          final booking = bookings[index];

                          return Card(
                            margin: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            child: ListTile(
                              leading: const CircleAvatar(
                                child:
                                    Icon(Icons.calendar_month),
                              ),
                              title: Text(booking.customerName),
                              subtitle: Text(
                                'Phone: ${booking.phoneNumber}\n'
                                'Room: ${booking.rooms.join(', ')}\n'
                                'Check-in: ${_formatDate(booking.checkIn)}',
                              ),
                              trailing: const Icon(
                                Icons.arrow_forward_ios,
                                size: 18,
                              ),
                              isThreeLine: true,
                              onTap: () async {
                                final result =
                                    await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        BookingDetailsScreen(
                                      booking: booking,
                                    ),
                                  ),
                                );

                                if (result == true && mounted) {
                                  setState(() {});
                                }
                              },
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
