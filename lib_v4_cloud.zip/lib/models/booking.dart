import 'package:hive/hive.dart';

class Booking {
  final String bookingId;
  final String customerName;
  final String phoneNumber;
  final String address;
  final int guests;
  final List<String> rooms;
  final DateTime checkIn;
  final DateTime checkOut;
  final double totalAmount;
  final double advanceAmount;
  final double balanceAmount;
  final String notes;

  Booking({
    required this.bookingId,
    required this.customerName,
    required this.phoneNumber,
    required this.address,
    required this.guests,
    required this.rooms,
    required this.checkIn,
    required this.checkOut,
    required this.totalAmount,
    required this.advanceAmount,
    required this.balanceAmount,
    required this.notes,
  });
}

class BookingAdapter extends TypeAdapter<Booking> {
  @override
  final int typeId = 0;

  @override
  Booking read(BinaryReader reader) {
    final fieldCount = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < fieldCount; i++) reader.readByte(): reader.read(),
    };

    return Booking(
      bookingId: fields[0] as String,
      customerName: fields[1] as String,
      phoneNumber: fields[2] as String,
      address: fields[3] as String,
      guests: fields[4] as int,
      rooms: List<String>.from(fields[5] as List),
      checkIn: fields[6] as DateTime,
      checkOut: fields[7] as DateTime,
      totalAmount: (fields[8] as num).toDouble(),
      advanceAmount: (fields[9] as num).toDouble(),
      balanceAmount: (fields[10] as num).toDouble(),
      notes: fields[11] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Booking booking) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(booking.bookingId)
      ..writeByte(1)
      ..write(booking.customerName)
      ..writeByte(2)
      ..write(booking.phoneNumber)
      ..writeByte(3)
      ..write(booking.address)
      ..writeByte(4)
      ..write(booking.guests)
      ..writeByte(5)
      ..write(booking.rooms)
      ..writeByte(6)
      ..write(booking.checkIn)
      ..writeByte(7)
      ..write(booking.checkOut)
      ..writeByte(8)
      ..write(booking.totalAmount)
      ..writeByte(9)
      ..write(booking.advanceAmount)
      ..writeByte(10)
      ..write(booking.balanceAmount)
      ..writeByte(11)
      ..write(booking.notes);
  }
}
