import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/booking.dart';

class BookingService {
  static const List<String> allRooms = [
    'Master Room 1',
    'Master Room 2',
    'Queen Room 1',
    'Queen Room 2',
    'Penthouse',
  ];

  static const String _boxName = 'govistays_bookings';

  static late Box<Booking> _bookingBox;
  static final List<Booking> bookings = [];

  /// Increases whenever bookings are added, edited, deleted, or reloaded.
  /// Screens can listen to this value and rebuild automatically.
  static final ValueNotifier<int> changeNotifier = ValueNotifier<int>(0);

  static Future<void> initialize() async {
    await Hive.initFlutter();

    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(BookingAdapter());
    }

    _bookingBox = await Hive.openBox<Booking>(_boxName);
    _reloadFromDatabase();
  }

  static void _reloadFromDatabase() {
    bookings
      ..clear()
      ..addAll(_bookingBox.values);

    _sortBookings();
    _notifyChanges();
  }

  static void _sortBookings() {
    bookings.sort((a, b) => a.checkIn.compareTo(b.checkIn));
  }

  static void _notifyChanges() {
    changeNotifier.value++;
  }

  static DateTime _dateOnly(DateTime value) {
    return DateTime(value.year, value.month, value.day);
  }

  static bool _isSameDay(DateTime first, DateTime second) {
    return first.year == second.year &&
        first.month == second.month &&
        first.day == second.day;
  }

  static String _normalizeRoomName(String room) {
    return room.trim().toLowerCase();
  }

  static String generateBookingId() {
    return 'GST${DateTime.now().millisecondsSinceEpoch}';
  }

  static bool addBooking(Booking booking) {
    for (final room in booking.rooms) {
      if (!isRoomAvailable(room, booking.checkIn, booking.checkOut)) {
        return false;
      }
    }

    bookings.add(booking);
    _sortBookings();
    _bookingBox.put(booking.bookingId, booking);
    _notifyChanges();

    return true;
  }

  static void deleteBooking(Booking booking) {
    bookings.removeWhere((b) => b.bookingId == booking.bookingId);
    _bookingBox.delete(booking.bookingId);
    _notifyChanges();
  }

  static bool updateBooking(Booking oldBooking, Booking newBooking) {
    for (final room in newBooking.rooms) {
      if (!isRoomAvailable(
        room,
        newBooking.checkIn,
        newBooking.checkOut,
        ignoreBookingId: oldBooking.bookingId,
      )) {
        return false;
      }
    }

    final index = bookings.indexWhere(
      (booking) => booking.bookingId == oldBooking.bookingId,
    );

    if (index == -1) {
      return false;
    }

    bookings[index] = newBooking;
    _sortBookings();
    _bookingBox.put(newBooking.bookingId, newBooking);
    _notifyChanges();

    return true;
  }

  static bool isRoomAvailable(
    String room,
    DateTime checkIn,
    DateTime checkOut, {
    String? ignoreBookingId,
  }) {
    final normalizedRoom = _normalizeRoomName(room);

    for (final booking in bookings) {
      if (booking.bookingId == ignoreBookingId) continue;

      final bookingHasRoom = booking.rooms.any(
        (bookedRoom) =>
            _normalizeRoomName(bookedRoom) == normalizedRoom,
      );

      if (!bookingHasRoom) continue;

      final overlaps = checkIn.isBefore(booking.checkOut) &&
          checkOut.isAfter(booking.checkIn);

      if (overlaps) {
        return false;
      }
    }

    return true;
  }

  static List<Booking> getTodayCheckIns() {
    final today = DateTime.now();
    final result = bookings
        .where((booking) => _isSameDay(booking.checkIn, today))
        .toList();

    result.sort((a, b) => a.customerName.compareTo(b.customerName));
    return result;
  }

  static List<Booking> getTodayCheckOuts() {
    final today = DateTime.now();
    final result = bookings
        .where((booking) => _isSameDay(booking.checkOut, today))
        .toList();

    result.sort((a, b) => a.customerName.compareTo(b.customerName));
    return result;
  }

  static List<Booking> getCurrentGuests() {
    final today = _dateOnly(DateTime.now());

    final result = bookings.where((booking) {
      final checkIn = _dateOnly(booking.checkIn);
      final checkOut = _dateOnly(booking.checkOut);

      // Guest is current from check-in day until the day before check-out.
      return !today.isBefore(checkIn) && today.isBefore(checkOut);
    }).toList();

    result.sort((a, b) => a.checkOut.compareTo(b.checkOut));
    return result;
  }

  static List<Booking> getFutureBookings() {
    final today = _dateOnly(DateTime.now());

    final result = bookings.where((booking) {
      return _dateOnly(booking.checkIn).isAfter(today);
    }).toList();

    result.sort((a, b) => a.checkIn.compareTo(b.checkIn));
    return result;
  }

  /// Filters any booking list by customer name, phone number, or booking ID.
  static List<Booking> searchBookings(
    List<Booking> source,
    String query,
  ) {
    final normalizedQuery = query.trim().toLowerCase();

    if (normalizedQuery.isEmpty) {
      return List<Booking>.from(source);
    }

    return source.where((booking) {
      return booking.customerName.toLowerCase().contains(normalizedQuery) ||
          booking.phoneNumber.toLowerCase().contains(normalizedQuery) ||
          booking.bookingId.toLowerCase().contains(normalizedQuery);
    }).toList();
  }

  /// Returns true when the given room is occupied today.
  ///
  /// Room names are compared after trimming spaces and converting to
  /// lowercase, preventing mismatches caused by formatting differences.
  static bool isRoomOccupiedToday(String room) {
    final today = _dateOnly(DateTime.now());
    final normalizedRoom = _normalizeRoomName(room);

    for (final booking in bookings) {
      final bookingHasRoom = booking.rooms.any(
        (bookedRoom) =>
            _normalizeRoomName(bookedRoom) == normalizedRoom,
      );

      if (!bookingHasRoom) continue;

      final checkIn = _dateOnly(booking.checkIn);
      final checkOut = _dateOnly(booking.checkOut);

      // Occupied from check-in day until the day before check-out.
      if (!today.isBefore(checkIn) && today.isBefore(checkOut)) {
        return true;
      }
    }

    return false;
  }

  static Set<String> get occupiedRoomsToday {
    return allRooms
        .where((room) => isRoomOccupiedToday(room))
        .toSet();
  }

  static int get totalRoomsCount => allRooms.length;
  static int get occupiedRoomsCount => occupiedRoomsToday.length;
  static int get availableRoomsCount =>
      totalRoomsCount - occupiedRoomsCount;

  static double get occupancyPercentage {
    if (totalRoomsCount == 0) return 0;
    return (occupiedRoomsCount / totalRoomsCount) * 100;
  }

  static int get todayCheckInsCount => getTodayCheckIns().length;
  static int get todayCheckOutsCount => getTodayCheckOuts().length;
  static int get currentGuestsCount => getCurrentGuests().length;
  static int get futureBookingsCount => getFutureBookings().length;
}
